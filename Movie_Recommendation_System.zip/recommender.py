def load_movies(filename):
    movie_data = {}
    try:
        with open(filename, 'r') as file:
            for line in file:
                if ':' in line:
                    genre, movies = line.strip().split(':')
                    movie_list = [movie.strip() for movie in movies.split(',')]
                    movie_data[genre.strip().lower()] = movie_list
    except FileNotFoundError:
        print("Error: movies.txt file not found!")
    return movie_data

def recommend_movies(movie_data, user_genres):
    recommendations = []
    for genre in user_genres:
        genre = genre.lower()
        if genre in movie_data:
            recommendations.extend(movie_data[genre])
        else:
            print(f"Sorry, no movies found for genre: {genre}")
    return recommendations

def main():
    filename = "movies.txt"
    movie_data = load_movies(filename)
    
    print("\n🎬 Welcome to Movie Recommender 🎬")
    print("Available genres:", ', '.join(movie_data.keys()))

    user_input = input("Enter your favorite genres (comma-separated): ")
    user_genres = [g.strip() for g in user_input.split(',')]

    result = recommend_movies(movie_data, user_genres)
    
    if result:
        print("\n🎥 Recommended Movies for You:")
        for movie in result:
            print(f"- {movie}")
    else:
        print("No recommendations found. Try different genres.")

if __name__ == "__main__":
    main()
